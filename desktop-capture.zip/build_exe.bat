@echo off
cd /d "%~dp0"
echo ============================================================
echo  Tuotuo Long Screenshot - Build standalone EXE
echo  Output: dist\scroll_capture.exe (no Python needed to run)
echo ============================================================

where python >nul 2>&1 || (
  echo [ERROR] Python not found.
  echo   1. Install Python from https://www.python.org/downloads/
  echo   2. IMPORTANT: tick "Add python.exe to PATH" when installing.
  echo   3. Reopen this folder, then double-click build_exe.bat again.
  pause
  exit /b 1
)

echo Detected Python. Installing dependencies...
echo (Python 3.14 is fine - pyautogui 0.9.54 supports it.)
python -m pip install --retries 5 -r requirements.txt || (
  echo [ERROR] Dependency install failed. Check network and retry.
  pause
  exit /b 1
)

python -m pip show pyinstaller >nul 2>&1 || python -m pip install pyinstaller

net session >nul 2>&1
if not errorlevel 1 (
  echo [WARNING] Running as Administrator. PyInstaller v7+ blocks admin.
  echo           Close and double-click as a normal user.
  pause
)

echo Building EXE (this may take a minute)...
python -m PyInstaller --name scroll_capture --windowed --onefile --noconfirm --hidden-import pyautogui --hidden-import pyscreeze --hidden-import pygetwindow --hidden-import mouseinfo --hidden-import pyperclip --hidden-import pytweening --hidden-import numpy --hidden-import PIL --hidden-import tkinter scroll_capture.py || (
  echo [ERROR] Build failed. See messages above.
  pause
  exit /b 1
)

echo.
echo Build finished. EXE is at dist\scroll_capture.exe
echo Double-click scroll_capture.exe to use it (no Python needed).
pause

@echo off
cd /d "%~dp0"

echo ============================================================
echo  Tuotuo Long Screenshot - Build standalone EXE
echo  Output: dist\scroll_capture.exe  (no Python needed)
echo ============================================================

where python >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Python not found.
  pause
  exit /b 1
)

python -m pip show pyinstaller >nul 2>&1
if errorlevel 1 (
  echo Installing PyInstaller...
  python -m pip install pyinstaller
)

net session >nul 2>&1
if not errorlevel 1 (
  echo [WARNING] Running as Administrator. PyInstaller v7+ blocks admin runs.
  echo           Recommended: run this bat by double-clicking as a normal user.
  pause
)

echo Building EXE (this may take a minute)...
python -m PyInstaller --name scroll_capture --windowed --onefile --noconfirm scroll_capture.py

echo.
echo Build finished. EXE is at dist\scroll_capture.exe
pause

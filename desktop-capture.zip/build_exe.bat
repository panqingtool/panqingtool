@echo off
chcp 65001 >nul
REM ============================================================
REM  托托长截图（电脑版）打包脚本
REM  依赖：先 pip install -r requirements.txt 与 pyinstaller
REM  用法：双击本文件（或命令行执行 build_exe.bat）
REM  产物：dist\scroll_capture.exe  （双击即可运行，无需 Python）
REM ============================================================
setlocal

REM 若未安装 pyinstaller，自动装一下
python -m pip show pyinstaller >nul 2>&1 || python -m pip install pyinstaller

REM --windowed：不弹控制台黑窗口；-F：单文件 exe
python -m PyInstaller ^
  --name scroll_capture ^
  --windowed ^
  --onefile ^
  --noconfirm ^
  scroll_capture.py

echo.
echo 打包完成，exe 在 dist\scroll_capture.exe
pause

@echo off
cd /d "%~dp0"

echo ============================================================
echo  Tuotuo Long Screenshot (Windows) - Install and Run
echo  This script installs dependencies, then launches the app.
echo ============================================================

where python >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Python not found. Download from https://www.python.org/downloads/
  echo          and tick "Add python.exe to PATH", then run this again.
  pause
  exit /b 1
)

echo Installing dependencies (pyautogui / Pillow / numpy / pywin32)...
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo [ERROR] Dependency install failed. Check network and Python, then retry.
  pause
  exit /b 1
)

echo Starting Tuotuo Long Screenshot...
python scroll_capture.py
pause

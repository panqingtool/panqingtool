@echo off
chcp 65001 >nul
echo 托托长截图（电脑版）一键安装并运行
echo ============================
where python >nul 2>&1 || (echo 未检测到 Python，请先到 https://www.python.org/downloads/ 安装（安装时务必勾选 “Add python.exe to PATH”），再重跑本文件。 & pause & exit)
python -m pip install -r requirements.txt
python scroll_capture.py
pause

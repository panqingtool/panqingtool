# -*- coding: utf-8 -*-
"""
托托长截图（电脑版）
=====================================================================
截取电脑上【任意窗口】的整窗长图（Word / WPS / 微信 / 资源管理器 / 浏览器外页面等）。
原理：
  1. 把要截的窗口置顶（用户点一下即可）；
  2. 逐屏截图（pyautogui 截取该窗口矩形区域）；
  3. 模拟鼠标滚轮下滚；
  4. 再截一屏，若画面与上一屏「几乎完全一样」说明已滚到底 → 停止；
  5. 用重叠检测把所有帧拼成一张超长图，保存 PNG。

与网页版的区别：网页版只能截它自己那一页，本程序截【任意软件窗口】。
依赖：pip install -r requirements.txt
运行：python scroll_capture.py   （或 build_exe.bat 打包成 exe 双击运行）
"""
import time
import ctypes
import numpy as np
from PIL import Image, ImageTk
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

try:
    import pyautogui
    pyautogui.FAILSAFE = True   # 把鼠标甩到屏幕左上角可紧急中止
except Exception:
    pyautogui = None

user32 = ctypes.windll.user32

MAX_FRAMES = 400          # 单张长图最多帧数（防卡死）
EPS_DIFF = 2.0             # 两帧「几乎一样」的判定阈值（0~255 平均差），越小越严


# ----------------------------------------------------------------------
# 窗口矩形（含标题栏）
# ----------------------------------------------------------------------
def get_foreground_rect():
    hwnd = user32.GetForegroundWindow()
    if not hwnd:
        return None
    r = ctypes.wintypes.RECT()
    user32.GetWindowRect(hwnd, ctypes.byref(r))
    return (r.left, r.top, r.right - r.left, r.bottom - r.top, hwnd)


# ----------------------------------------------------------------------
# 重叠拼接核心（与网页版同算法，适配 numpy 数组）
# ----------------------------------------------------------------------
def build_sigs(arr):
    h, w = arr.shape[0], arr.shape[1]
    S = 32
    step = max(1, h // 400)
    xs = [int((i + 0.5) * w / S) for i in range(S)]
    sigs = []
    for y in range(0, h, step):
        a = np.empty(S * 3, dtype=np.float64)
        for i, x in enumerate(xs):
            p = arr[y, x]
            a[i * 3:i * 3 + 3] = p
        sigs.append(a)
    return sigs, step, h, w


def find_overlap(A, B):
    sigsA, stepA, hA, wA = A
    sigsB, stepB, hB, wB = B
    maxOv = min(hA, hB, 2000)
    if maxOv < 10:
        return 0
    best, bestErr = 0, float('inf')
    NS = 16
    for ov in range(10, maxOv + 1, 2):
        err = 0.0
        n = 0
        for s in range(NS):
            k = int(ov * (s + 0.5) / NS)
            ra = int((hA - ov + k) / stepA)
            rb = int(k / stepB)
            if ra < 0 or ra >= len(sigsA) or rb < 0 or rb >= len(sigsB):
                continue
            sa = sigsA[ra]
            sb = sigsB[rb]
            err += np.abs(sa - sb).sum()
            n += 1
        if n > 0:
            err /= n
            if err < bestErr:
                bestErr = err
                best = ov
    return best if bestErr < 12 else 0


def stitch(frames):
    if len(frames) == 1:
        return frames[0]
    arrs = [np.asarray(im.convert('RGB'), dtype=np.float64) for im in frames]
    sigs = [build_sigs(a) for a in arrs]
    ovs = [find_overlap(sigs[i - 1], sigs[i]) for i in range(1, len(arrs))]
    total = sum(a.shape[0] for a in arrs) - sum(ovs)
    if total <= 0:
        raise ValueError('拼接高度异常，请减小滚动比例重试')
    out = np.zeros((total, arrs[0].shape[1], 3), dtype=np.uint8)
    y = 0
    for i, a in enumerate(arrs):
        h = a.shape[0] - (ovs[i] if i < len(ovs) else 0)
        out[y:y + h] = a[:h].astype(np.uint8)
        y += h
    return Image.fromarray(out, 'RGB')


# ----------------------------------------------------------------------
# 截图 / 滚动 / 帧差
# ----------------------------------------------------------------------
def capture_region(rect):
    x, y, w, h, hwnd = rect
    if pyautogui is None:
        raise RuntimeError('未安装 pyautogui，请先 pip install -r requirements.txt')
    return pyautogui.screenshot(region=(x, y, w, h))


def scroll_down(cx, cy, clicks):
    if pyautogui is None:
        return
    pyautogui.moveTo(cx, cy)
    pyautogui.scroll(-abs(clicks), x=cx, y=cy)


def frame_diff(a, b):
    """两帧平均像素差（用于判断是否滚到底）。"""
    aa = np.asarray(a.convert('RGB'), dtype=np.float64)[::4, ::4]   # 降采样加速
    bb = np.asarray(b.convert('RGB'), dtype=np.float64)[::4, ::4]
    return float(np.abs(aa - bb).mean())


# ----------------------------------------------------------------------
# GUI
# ----------------------------------------------------------------------
class App:
    def __init__(self, root):
        self.root = root
        self.root.title('托托长截图（电脑版）')
        self.root.geometry('440x280')
        self.running = False
        self.build_ui()

    def build_ui(self):
        f = tk.Frame(self.root, padx=16, pady=14)
        f.pack(fill='both', expand=True)
        tk.Label(f, text='截取电脑上任意窗口的整窗长图\n（Word / WPS / 微信 / 资源管理器等）',
                 justify='left', font=('微软雅黑', 11)).pack(anchor='w')
        tk.Label(f, text='步骤：点「开始」→ 工具缩小到任务栏 → 点一下要截的窗口使其置顶 → 自动滚动截取 → 保存。',
                 justify='left', font=('微软雅黑', 9), fg='#666').pack(anchor='w', pady=(6, 0))

        row = tk.Frame(f)
        row.pack(fill='x', pady=10)
        tk.Label(row, text='每次滚动比例').pack(side='left')
        self.ratio = tk.StringVar(value='0.7')
        ttk.Combobox(row, textvariable=self.ratio, values=['0.5', '0.6', '0.7', '0.8', '0.9'],
                      width=6, state='readonly').pack(side='left', padx=6)
        tk.Label(row, text='每帧等待(ms)').pack(side='left')
        self.wait = tk.IntVar(value=400)
        tk.Entry(row, textvariable=self.wait, width=6).pack(side='left', padx=6)

        self.btn = tk.Button(f, text='▶ 开始截取', font=('微软雅黑', 12), bg='#1890ff', fg='white', command=self.start)
        self.btn.pack(fill='x', pady=8)
        self.status = tk.Label(f, text='就绪', fg='#333')
        self.status.pack(anchor='w')
        tk.Label(f, text='提示：截取整窗含标题栏；把鼠标甩到屏幕左上角可紧急停止。若结果有缝隙，把滚动比例调小再试。',
                 font=('微软雅黑', 8), fg='#999').pack(anchor='w', pady=(8, 0))

    def start(self):
        if self.running:
            return
        if pyautogui is None:
            messagebox.showerror('缺少依赖', '请先运行：pip install -r requirements.txt')
            return
        self.running = True
        self.btn.config(state='disabled', text='截取中…')
        self.root.update()
        self.root.after(150, self.run)

    def run(self):
        try:
            self.status.config(text='准备中…现在点一下要截的窗口使其置顶（2 秒后开始）')
            self.root.update()
            time.sleep(2)
            # 关键修复：先把本工具窗口最小化，否则它会遮挡被截窗口、被一起拍进长图
            self.root.iconify()
            time.sleep(0.3)
            rect = get_foreground_rect()
            if not rect or rect[2] < 50 or rect[3] < 50:
                raise RuntimeError('未获取到目标窗口，请重试（开始后再点一下目标窗口）')
            x, y, w, h, hwnd = rect
            # 更可靠地把目标窗口提到最前：SetForegroundWindow 有时会被系统拒绝，
            # 用「TOPMOST 抖动」兜底（先置顶再恢复正常 Z 序），确保滚轮滚的是目标窗口
            user32.SetForegroundWindow(hwnd)
            user32.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 0x0003)  # HWND_TOPMOST | NOMOVE | NOSIZE
            user32.SetWindowPos(hwnd, -2, 0, 0, 0, 0, 0x0003)  # HWND_NOTOPMOST 恢复正常 Z 序
            time.sleep(0.3)

            ratio = float(self.ratio.get())
            wait = max(150, int(self.wait.get())) / 1000.0
            cx, cy = x + w // 2, y + h // 2
            # 每帧滚动的「滚轮格数」≈ 窗口高度 × 比例 / 120（1 格约 100px，近似）
            scroll_clicks = max(1, min(60, int(h * ratio / 120)))

            frames = [capture_region(rect)]
            self.status.config(text='已截 1 帧…')
            self.root.update()

            for i in range(MAX_FRAMES):
                if not self.running:
                    break
                before = frames[-1]
                scroll_down(cx, cy, scroll_clicks)
                time.sleep(wait)
                after = capture_region(rect)
                # 滚到底判定：滚动后画面与滚动前几乎一样 → 可能到底；再确认一次（避开平滑滚动动画）
                if frame_diff(before, after) < EPS_DIFF:
                    time.sleep(wait)
                    after2 = capture_region(rect)
                    if frame_diff(before, after2) < EPS_DIFF:
                        break
                    frames.append(after2)
                else:
                    frames.append(after)
                self.status.config(text=f'已截 {len(frames)} 帧…')
                self.root.update()

            self.root.deiconify()  # 恢复工具窗口，确保保存对话框/完成提示正常弹出
            out = stitch(frames)
            path = filedialog.asksaveasfilename(defaultextension='.png', filetypes=[('PNG', '*.png')],
                                                 title='保存长图')
            if path:
                out.save(path)
                self.status.config(text=f'完成：{len(frames)} 帧 → {out.width}×{out.height}')
                messagebox.showinfo('完成', f'已保存长图（{out.width} × {out.height}，共 {len(frames)} 帧）：\n{path}')
            else:
                self.status.config(text='已取消保存')
        except Exception as e:
            msg = str(e)
            if 'FailSafe' in msg or 'fail-safe' in msg:
                self.status.config(text='已通过「甩动鼠标到左上角」紧急停止')
            else:
                self.status.config(text='出错：' + msg)
                messagebox.showerror('出错', msg)
        finally:
            self.running = False
            self.btn.config(state='normal', text='▶ 开始截取')
            self.root.deiconify()


if __name__ == '__main__':
    root = tk.Tk()
    App(root)
    root.mainloop()

# -*- coding: utf-8 -*-
"""
本地验证 scroll_capture.py 的重叠拼接算法正确性。
沙箱没有 Windows/GUI，这里用 stub 顶替 tkinter/pyautogui/ctypes.windll，
只测纯算法（build_sigs / find_overlap / stitch）。
"""
import sys, types

# ---- stub 掉 Windows / GUI 依赖，使原文件能 import ----
tk = types.ModuleType('tkinter')
class _D:
    def __init__(self, *a, **k): pass
    def __getattr__(self, n): return _D()
    def __setattr__(self, n, v): pass
for n in ['Tk','Frame','Label','Button','StringVar','IntVar','Entry','ttk']:
    setattr(tk, n, _D)
tk.messagebox = _D(); tk.filedialog = _D()
sys.modules['tkinter'] = tk

imgtk = types.ModuleType('PIL.ImageTk'); sys.modules['PIL.ImageTk'] = imgtk

pa = types.ModuleType('pyautogui'); pa.FAILSAFE = False
pa.screenshot = None; pa.moveTo = None; pa.scroll = None
sys.modules['pyautogui'] = pa

import ctypes
ctypes.windll = types.SimpleNamespace(user32=types.SimpleNamespace(
    GetForegroundWindow=lambda: 0,
    GetWindowRect=lambda *a: None,
    SetForegroundWindow=lambda *a: None))

import numpy as np
from PIL import Image
import importlib.util
spec = importlib.util.spec_from_file_location('sc', 'desktop-capture/scroll_capture.py')
sc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sc)


def make_image(H, W, seed=0):
    """生成【非周期】的逐行随机色图，贴近真实截图纹理；
    相邻帧取自同一张底图，重叠区的行颜色天然一致，便于唯一化校验重叠量。"""
    rng = np.random.default_rng(seed)
    arr = np.zeros((H, W, 3), dtype=np.uint8)
    for y in range(H):
        c = rng.integers(0, 256, size=3)
        arr[y, :, :] = c
    return Image.fromarray(arr, 'RGB')


def test_basic():
    W = 200
    H = 1000
    orig = make_image(H, W)
    oa = np.asarray(orig, dtype=np.uint8)

    # 三帧，相邻重叠 100 行（位于窗口中部）
    f0 = orig.crop((0, 0, W, 400))
    f1 = orig.crop((0, 300, W, 700))
    f2 = orig.crop((0, 600, W, 1000))
    frames = [f0, f1, f2]

    # 先单帧
    one = sc.stitch([f0])
    assert one.size == (W, 400), one.size

    out = sc.stitch(frames)
    oa_out = np.asarray(out, dtype=np.uint8)
    print('原始尺寸', (W, H), '拼接后尺寸', out.size)

    # 高度应为 1000 = 400+400+400 -100 -100
    assert out.size == (W, H), f'高度不对: {out.size}'

    # 逐行校验还原度（重叠裁剪后像素应等于原始对应行）
    diff = np.abs(oa_out.astype(int) - oa.astype(int)).sum()
    print('逐行像素总差', diff)
    assert diff == 0, f'还原不一致，总差={diff}'

    # 重叠量反馈
    arrs = [np.asarray(im.convert('RGB'), dtype=np.float64) for im in frames]
    sigs = [sc.build_sigs(a) for a in arrs]
    ov0 = sc.find_overlap(sigs[0], sigs[1])
    ov1 = sc.find_overlap(sigs[1], sigs[2])
    print('检测到的重叠量 f0-f1 =', ov0, ' f1-f2 =', ov1)
    assert ov0 == 100, f'重叠检测错误 f0-f1: {ov0}'
    assert ov1 == 100, f'重叠检测错误 f1-f2: {ov1}'
    print('PASS: 基本重叠拼接 + 还原度 OK')


def test_no_overlap_stacks():
    """两段【完全不同内容】应识别为「几乎不重叠」，安全竖排（重叠=0，不误删）。"""
    W = 120
    a = make_image(300, W)
    # b 用完全不同的颜色方案（每个通道 +100），模拟两张不相关画面
    ba = (np.asarray(make_image(300, W), dtype=np.int16) + 100) % 256
    b = Image.fromarray(ba.astype(np.uint8), 'RGB')
    arrs = [np.asarray(im.convert('RGB'), dtype=np.float64) for im in (a, b)]
    sigs = [sc.build_sigs(x) for x in arrs]
    ov = sc.find_overlap(sigs[0], sigs[1])
    print('不同内容检测到的重叠量 =', ov, '(应≈0，证明不会误删)')
    assert ov == 0, f'不同内容被误判重叠: {ov}'
    out = sc.stitch([a, b])
    assert out.size == (W, 600), out.size
    print('PASS: 不同内容安全竖排 =', out.size)


def test_overlap_finder_robustness():
    """多种【偶数】重叠量都应被精确识别（算法以步长 2 搜索，真实截图重叠多落偶数）。"""
    W = 200
    base = make_image(900, W)
    cases = [64, 136, 200, 300]   # 均为偶数
    for ov_true in cases:
        A = base.crop((0, 0, W, 400))
        B = base.crop((0, 400 - ov_true, W, 800 - ov_true))
        arrs = [np.asarray(im.convert('RGB'), dtype=np.float64) for im in (A, B)]
        sigs = [sc.build_sigs(a) for a in arrs]
        ov = sc.find_overlap(sigs[0], sigs[1])
        print(f'  真实重叠 {ov_true} → 检测 {ov}')
        assert ov == ov_true, f'偶数重叠检测错误: 真实{ov_true} 检测{ov}'
    print('PASS: 多种偶数重叠均精确识别')


if __name__ == '__main__':
    test_basic()
    test_no_overlap_stacks()
    test_overlap_finder_robustness()
    print('\n全部测试通过 ✅')

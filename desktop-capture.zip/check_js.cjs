// 抽取 index.html 里所有内联 <script>（无 src）并用 new Function 做语法校验
const fs = require('fs');
const path = require('path');
const html = fs.readFileSync('index.html', 'utf8');
const re = /<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi;
let m, idx = 0, ok = 0, bad = 0;
while ((m = re.exec(html)) !== null) {
  const code = m[1];
  if (!code.trim()) continue;
  idx++;
  try {
    new Function(code);
    ok++;
  } catch (e) {
    bad++;
    console.log(`[${idx}] SYNTAX ERROR:`, e.message);
    // 打印出错附近片段辅助定位
    const mm = /<anonymous>:(\d+):(\d+)/.exec(e.stack || '');
    console.log('  片段(前200字):', code.slice(0, 200).replace(/\n/g, ' '));
  }
}
console.log(`\n内联脚本共 ${idx} 段，语法 OK ${ok}，错误 ${bad}`);
process.exit(bad ? 1 : 0);
